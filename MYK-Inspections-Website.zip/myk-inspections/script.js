const menu=document.querySelector(".menu"),nav=document.querySelector(".nav nav");
menu.addEventListener("click",()=>nav.classList.toggle("open"));
document.querySelectorAll(".nav nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const service=document.getElementById("service"), estimate=document.getElementById("estimate");
service.addEventListener("change",()=>{
  if(!service.value){estimate.textContent="$0";return}
  const price=service.value.split("|")[1];
  estimate.textContent="$"+price;
});

const date=document.getElementById("date");
const today=new Date();
today.setMinutes(today.getMinutes()-today.getTimezoneOffset());
date.min=today.toISOString().split("T")[0];

document.getElementById("yearNow").textContent=new Date().getFullYear();

document.getElementById("bookingForm").addEventListener("submit",e=>{
  e.preventDefault();
  const msg=document.getElementById("formMessage");
  msg.textContent="Your form is complete, but this demo is not connected to a booking database yet. Connect the form to your email, scheduling system, or backend before publishing.";
  msg.style.color="#7a6200";
  msg.scrollIntoView({behavior:"smooth",block:"center"});
});
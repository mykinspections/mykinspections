MYK INSPECTIONS WEBSITE

Files:
- index.html
- styles.css
- script.js

Open index.html in a browser to preview the site.

IMPORTANT BEFORE PUBLISHING
1. The appointment form currently works as a front-end demo only. It does not transmit or store customer information.
2. Connect the form to a secure booking/backend service before taking real appointments.
3. Add the business phone number, email address, legal business name/entity, and any required license/PIF information.
4. Have the Terms & Conditions reviewed for your exact New Jersey operation before using them for paid appointments.
5. Long-distance pricing is intentionally shown as "custom quote" until MYK chooses a fee.
6. Do not collect sensitive customer information through an unsecured email-only form. Use HTTPS and an appropriate secure backend.
